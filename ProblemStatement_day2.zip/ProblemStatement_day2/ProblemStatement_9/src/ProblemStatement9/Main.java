package ProblemStatement9;

public class Main {

}
