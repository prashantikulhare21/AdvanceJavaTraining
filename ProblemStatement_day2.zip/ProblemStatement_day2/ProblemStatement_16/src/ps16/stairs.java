package ps16;

public class stairs {

}
