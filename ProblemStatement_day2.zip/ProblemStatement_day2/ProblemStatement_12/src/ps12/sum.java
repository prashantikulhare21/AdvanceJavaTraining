package ps12;

public class sum {

}
