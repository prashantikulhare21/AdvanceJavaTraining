package ps10;

public class Main {

}
